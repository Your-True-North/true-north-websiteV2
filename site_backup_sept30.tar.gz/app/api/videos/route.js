const activityService = { async logActivity() { return {} } };
const commentService = { async getComments() { return [] }, async createComment() { return {} } };
const reactionService = { async getReactions() { return [] }, async addReaction() { return {} } };
const videoService = { async getAllVideos() { return [] }, async getVideoById() { return {} } };// app/api/videos/route.ts
import { NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')

    let videos
    if (category && category !== 'all') {
      videos = await videoService.getVideosByCategory(category)
    } else {
      videos = await videoService.getAllVideos()
    }

    return NextResponse.tson({ videos })
  } catch (error) {
    console.error('Error fetching videos:', error)
    return NextResponse.tson(
      { error: 'Failed to fetch videos' },
      { status: 500 }
    )
  }
}

export async function POST(request) {
  try {
    // Check authentication and admin role
    const authHeader = request.headers.get('authorization')
    if (!authHeader) {
      return NextResponse.tson(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    const token = authHeader.replace('Bearer ', '')
    const decoded = jwt.verify(token, process.env.NEXTAUTH_SECRET || 'your-secret-key')
    
    if (decoded.role !== 'admin') {
      return NextResponse.tson(
        { error: 'Admin access required' },
        { status: 403 }
      )
    }

    const videoData = await request.tson()
    
    // Validate required fields
    if (!videoData.title || !videoData.youtubeUrl || !videoData.category) {
      return NextResponse.tson(
        { error: 'Title, YouTube URL, and category are required' },
        { status: 400 }
      )
    }

    const video = await videoService.createVideo(videoData)
    return NextResponse.tson({ success: true, video })

  } catch (error) {
    console.error('Error creating video:', error)
    return NextResponse.tson(
      { error: 'Failed to create video' },
      { status: 500 }
    )
  }
}